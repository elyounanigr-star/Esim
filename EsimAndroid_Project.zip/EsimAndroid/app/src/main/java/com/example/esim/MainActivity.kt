package com.example.esim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF071A35)
private val Panel = Color(0xFF102B50)
private val Blue = Color(0xFF3285F6)
private val Muted = Color(0xFF9CB2D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EsimApp() }
    }
}

data class Feature(val name: String, val detail: String, val icon: ImageVector)

@Composable
fun EsimApp() {
    var selectedTab by remember { mutableStateOf("Home") }
    var sim by remember { mutableStateOf("SIM 1") }
    val features = listOf(
        Feature("Phone", "Make a call", Icons.Default.Call),
        Feature("Messages", "Send and receive SMS", Icons.Default.Sms),
        Feature("Schedule SMS", "Plan a message", Icons.Default.Schedule),
        Feature("Call history", "Recent calls", Icons.Default.History),
        Feature("Contacts", "Manage contacts", Icons.Default.Contacts),
        Feature("Delivery reports", "SMS status", Icons.Default.DoneAll),
        Feature("Statistics", "Call activity", Icons.Default.BarChart)
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Calls", "SMS", "Contacts").forEach { item ->
                        NavigationBarItem(
                            selected = selectedTab == item,
                            onClick = { selectedTab = item },
                            icon = {
                                Icon(when(item) {
                                    "Calls" -> Icons.Default.Call
                                    "SMS" -> Icons.Default.Sms
                                    "Contacts" -> Icons.Default.Contacts
                                    else -> Icons.Default.Home
                                }, contentDescription = item)
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                indicatorColor = Blue,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("ESIM", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text("DUAL SIM MANAGER", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    }
                    Icon(Icons.Default.SimCard, null, tint = Blue, modifier = Modifier.size(34.dp))
                }
                Text("Your connections", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("SIM 1", "SIM 2").forEach { item ->
                        Card(
                            onClick = { sim = item },
                            colors = CardDefaults.cardColors(containerColor = if (sim == item) Blue else Panel),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Icon(Icons.Default.SimCard, null, tint = Color.White)
                                Spacer(Modifier.height(8.dp))
                                Text(item, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(if (sim == item) "Selected" else "Tap to select", color = Color.White.copy(.75f), fontSize = 12.sp)
                            }
                        }
                    }
                }
                Text("Quick access", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(features) { feature ->
                        Card(
                            onClick = { selectedTab = feature.name },
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Icon(feature.icon, null, tint = Blue, modifier = Modifier.size(28.dp))
                                Spacer(Modifier.height(14.dp))
                                Text(feature.name, color = Color.White, fontWeight = FontWeight.Bold)
                                Text(feature.detail, color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
                Text("Selected line: $sim  •  Device: Redmi 15C", color = Muted, fontSize = 11.sp)
            }
        }
    }
}
