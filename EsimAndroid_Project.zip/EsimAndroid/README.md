# Esim Android app

A dark-blue Kotlin + Jetpack Compose starter project for the Xiaomi Redmi 15C.

## Open and build
1. Install Android Studio (current stable) on a computer.
2. Extract this ZIP and open the `EsimAndroid` folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if prompted.
4. Connect the Redmi 15C with USB debugging enabled.
5. Run the app, or use **Build > Build APK(s)**.
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important implementation notes
- This is the first UI/project build, not a finished telephony client.
- Android restricts SMS, call-log and default-phone-app capabilities. Requesting permissions alone does not grant all functionality.
- To implement full call handling, the app must qualify for and request the system default dialer role. SMS handling requires the default SMS role and compliant Play policy declarations if distributed through Google Play.
- Dual-SIM selection depends on carrier/device support and Android subscription APIs; the UI selector is currently a design placeholder, not yet wired to the modem.
- Scheduled SMS, delivery reports, contacts, call history and statistics still need their platform integrations and runtime permission flows.
- Do not distribute the app until these features, privacy disclosures, and permission handling have been completed and tested on the target phone.
